---
# This file exists describes the directory housing the tab components. If the
# URL is visited, it will immediately redirect to the Tab component.
title: "Tabs"
layout: detail
section: components
excerpt: "Components for tabbed navigation."
iconId: tabs
path: /catalog/tabs/
redirect_path: /catalog/tabs/tab-bar/
---

{% include redirect-page.html %}
