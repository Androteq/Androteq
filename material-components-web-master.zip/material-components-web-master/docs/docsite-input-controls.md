---
# This file exists describes the directory housing the input components. If the
# URL is visited, it will immediately redirect to the Form Fields component.
title: "Inputs and Controls"
layout: detail
section: components
excerpt: "Form fields, checkboxes, menus, and other input components."
iconId: text_field
path: /catalog/input-controls/
redirect_path: /catalog/input-controls/form-fields/
---

{% include redirect-page.html %}
