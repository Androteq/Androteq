# Bottom App Bar

The [Bottom App Bar component](https://material.io/go/design-app-bar-bottom) is yet to be completed, please follow the [tracking issue](https://github.com/material-components/material-components-web/issues/2659) for more information.

