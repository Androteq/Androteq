# Divider

The [Divider component](https://material.io/go/design-dividers) is yet to be completed, please follow the [tracking issue](https://github.com/material-components/material-components-web/issues/2662) for more information.

